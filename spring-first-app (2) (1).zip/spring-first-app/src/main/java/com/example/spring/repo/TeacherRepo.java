package com.example.spring.repo;

import com.example.spring.entity.Teacher;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface TeacherRepo extends ReactiveCrudRepository<Teacher,Integer> {
}
