package com.example.spring.controller;

import com.example.spring.entity.Teacher;
import com.example.spring.repo.TeacherRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/teacher")
public class TeacherController {

    @Autowired
    private TeacherRepo teacherRepo;
    @GetMapping("/findAll")
    public Flux<Teacher> getAllTeacher(){

        return teacherRepo.findAll();
    }
    @GetMapping("/teacher/{id}")
    public Mono<Teacher> getProductById(@PathVariable int id ){

        return teacherRepo.findById(id);

    }
    @PostMapping("/insert")
    public Mono<Teacher> insertTeacher(@RequestBody Teacher teacher )
    {
        return teacherRepo.save(teacher);
    }

    @PutMapping("/update/{id}")
    public Mono<Teacher> updateTeacherById(@RequestBody Teacher teacher, @PathVariable int id){

        return teacherRepo.findById(id)
                .map(
                        (c)->{
                            c.setName(teacher.getName());
                            c.setEmail(teacher.getEmail());
                            return c ;
                        }) .flatMap(c->teacherRepo.save(c));

    }
    @DeleteMapping("/delete/{id}")
    public Mono<Void>deleteById(@PathVariable int id ){

       return teacherRepo.deleteById(id);
    }
}
